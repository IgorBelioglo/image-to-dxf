@echo off
title AutoCAD AI Tracer
echo Installing/checking required packages...
python -m pip install -r requirements.txt
echo.
echo Starting tracer...
python image_to_dxf.py
echo.
pause
