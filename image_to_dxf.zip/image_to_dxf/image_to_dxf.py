import pymupdf
import ezdxf
import os

def pdf_vector_to_dxf(pdf_path, dxf_path):
    if not os.path.exists(pdf_path):
        print(f"Ошибка: Файл '{pdf_path}' не найден в папке с кодом!")
        print("Пожалуйста, скопируйте файл Sec_3.pdf в текущую папку.")
        return

    # Открываем PDF
    doc_pdf = pymupdf.open(pdf_path)
    page = doc_pdf[0]
    
    height = page.rect.height

    # Создаем DXF
    doc_dxf = ezdxf.new("R2010")
    msp = doc_dxf.modelspace()

    # Извлекаем векторные элементы из PDF
    paths = page.get_drawings()
    print(f"Извлечено векторных элементов: {len(paths)}")

    for path in paths:
        for item in path["items"]:
            # Прямые линии
            if item[0] == "l":  
                p1, p2 = item[1], item[2]
                msp.add_line((p1.x, height - p1.y), (p2.x, height - p2.y))
            
            # Кривые линии
            elif item[0] == "c":  
                p1, p2, p3, p4 = item[1], item[2], item[3], item[4]
                msp.add_line((p1.x, height - p1.y), (p4.x, height - p4.y))

    doc_dxf.saveas(dxf_path)
    print(f"Успешно сохранен векторный чертеж: {dxf_path}")

if __name__ == "__main__":
    pdf_vector_to_dxf("Sec_3.pdf", "Sec_3_vector.dxf")